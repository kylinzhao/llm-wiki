# LLM Wiki Project Rules

## Query Routing

This repository is an LLM Wiki knowledge-base project. When the user asks a
business, product, requirement, terminology, policy, implementation-status, or
code-traceability question in this project, prefer the LLM Wiki query workflow
before answering from general model memory.

- For business knowledge, product rules, requirement interpretation, terminology,
  and source-backed facts, use `$llm-wiki-query` / `llm-wiki query` semantics.
- For questions that need both business evidence and code implementation evidence,
  use `$llm-wiki-query-plus` / `llm-wiki query-plus` semantics.
- If the user explicitly asks to initialize, refresh, audit, diagnose, or maintain
  the knowledge base, use the relevant `llm-wiki` command semantics instead of a
  plain chat answer.
- Before init/fast/update, require a non-empty `BUSINESS_CONTEXT.md` that has
  been filled beyond the bundled TODO placeholder.
- Always read `BUSINESS_CONTEXT.md` first, then follow
  `docs/retrieval-playbook.md` and the evidence hierarchy in `wiki/`.
- Do not answer business facts from memory when relevant wiki evidence exists.
  Cite the supporting wiki/source pages and call out evidence gaps.
- Prefer remote original wiki links when source_url/page_id metadata is available.
- Keep local raw/wiki snapshot links for reproducibility.
- Do not expose local raw/wiki paths in Cwiki comment drafts.

## Language Requirements

- Use Chinese for user-facing LLM Wiki answers, diagnostics, review reports, and final summaries by default.
- Generate or rewrite Markdown knowledge documents in `wiki/`, `docs/`, and `staging/` in Chinese by default.
- Keep code identifiers, commands, paths, API names, config keys, English proper nouns, and verbatim evidence excerpts in their original form when needed; explain them in Chinese.
- Use another language only when the user explicitly asks for it.

## Evidence Boundaries

- `raw/` is immutable source evidence. Read it; do not edit it.
- `raw-code/` is immutable code evidence. Read it; do not edit it.
- Keep `raw/` uncommitted. Gateway publish sync commits canonical staging state and generated wiki artifacts, while raw evidence is refreshed locally through wiki export/sync.
- Do not write secrets, cookies, tokens, private keys, or full sensitive config values into `wiki/`.

## Build Commands

Use `update_wiki.py` as the deterministic primary entrypoint:

```bash
uv run python tools/update_wiki.py
# optional when raw-code/ exists and graphify is installed:
uv run python tools/update_wiki.py --graphify
```

`tools/update_wiki.py` runs the deterministic chain (including health/graph/anchor checks). Traceability model work must follow `docs/traceability-contract.md`: the current agent or an external agent worker writes `staging/traceability/runs/<run_id>/proposals.json`, and deterministic tooling merges it into `staging/traceability/state.json` before rendering Markdown.

## Cwiki Authentication

When Cwiki upstream sync needs authentication, prefer the bundled `guazi-sso-login` flow over manually pasting `COOKIE_HEADER`. The same local setup script can also store an optional GitLab PAT for `git.guazi-corp.com` access when SSH Key / Git credential helper is not already configured. Ask the user to run the built-in setup script in a terminal, then return to the agent and continue update:

```bash
bash tools/confluence_sync/init_auth_env.sh
```

The script first reuses any existing local auth values, then prompts only for missing Guazi username, password, phone, optional Jira token, and optional `GUAZI_GITLAB_TOKEN`. It writes them only to `~/.llm-wiki/guazi-sso.env` with user-only permissions and does not write secrets into the KB project. Git operations first use existing SSH Key / Git credentials; the saved GitLab token is only used as an HTTPS GitLab fallback. The local SSO flow exchanges the credentials for a local Cwiki Cookie/login cache and reuses it until it expires. Jira issue reading should use `JIRA_TOKEN`; CHDSSO is only a fallback when no Jira token is available. If secrets are typed into an agent chat window, they may enter the current agent session context or local session history depending on the engine. A full `COOKIE_HEADER` is only a lower-priority one-off fallback.

Before asking the user to enter auth again, first check whether local auth is already present in `~/.llm-wiki/guazi-sso.env`, existing Git credentials, or the bundled `guazi-sso-login` cache/login records. If local auth already exists, do not ask the user to re-enter username, password, phone, Jira token, GitLab token, or Cookie unless you have evidence that the local auth state is invalid and cannot be refreshed automatically.
