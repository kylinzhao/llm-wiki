# 查询逻辑

## 1. 默认顺序

1. 读取 `BUSINESS_CONTEXT.md`，把它作为业务语义基线。
2. 判断查询意图，不要直接从模型记忆、单个 `rg` 命中或孤立代码片段下结论。
3. 先查 `wiki/overview.md`，确认站点范围、主链路和已知缺口。**不要读 `wiki/index.md` 的来源列表**——它只含域统计摘要，具体来源靠 grep/搜索定位。
4. 按查询意图选择专项目录层：`truth`、`conflicts`、`evidence`、`proposals`、`reference`、`operations`。
5. 使用 `concepts / entities` 作为通用扩展层，扩展主题、实体、别名和相关来源。
6. 回到 `sources` 找直接需求/业务证据。
7. 必要时回 `raw/` 核验原始证据。
8. 只有当问题明确涉及代码实现、系统架构、接口、调用链、落地状态、测试追踪或用户调用 `query-plus` 时，才进入 `wiki/code/`。

`concepts / entities` 不是最终证据层，也不替代 `evidence / operations / proposals / reference / truth / conflicts`。前者负责跨来源导航、实体归一和别名扩展；后者负责按问题意图定位候选事实视图。最终结论仍要回到 `sources` 或 `raw/` 支撑。

## 2. 检索预算与限流

查询应先收敛候选范围，再读取证据。默认不要把 `rg` 当成全库扫描器使用。

### 基本规则

1. 先读 `BUSINESS_CONTEXT.md` 与 `wiki/overview.md`，再按查询意图选择 1-3 个候选目录或候选文件。
2. 不要在整个 `wiki/` 目录上用高频词做无上限搜索，例如 `C1|车主|目标|工作|线索|卖车|当前` 这类组合。需要全局搜索时，必须先用更具体的实体、PRD 标题、Jira key、页面 ID、日期、功能名或业务对象缩小关键词。
3. `rg` 输出必须限流。优先使用更精确的 `--glob`、候选目录、`--max-count`、`-m`、`head` 或直接读取已定位文件；不要让单次搜索返回成千上万行。
4. 单次检索结果只用于定位候选证据，不作为最终结论。结论仍需回到 `sources`、专项目录层或必要的 `raw/` 页面核验。
5. 如果第一次搜索命中过多，停止扩搜，改为按目录层或最近/最相关 source 下钻；不要继续叠加更多高频词。

### 常见查询的优先收敛路径

- **当前重点 / 规划 / 周会进展**：优先读 `wiki/overview.md`、最近的 `wiki/sources/*周会*.md`、`wiki/proposals/index.md`，再下钻具体 PRD。不要全库搜索“重点/当前/工作/目标”。
- **规则 / 口径 / 稳定事实**：优先读 `truth`、`reference`、相关 concepts/entities，再回到 source。
- **问题 / 风险 / 冲突**：优先读 `conflicts`、`evidence`、`proposals`，再回到 source。
- **操作 / 维护 / 查询方式**：优先读 `operations` 与项目级说明。
- **代码实现**：先读 `wiki/code/traceability`、`wiki/code/capabilities`、`wiki/code/codebases` 的索引或相关页，再按明确符号/URI 搜索代码证据。

## 3. 查询模式

### `llm-wiki query`

默认按问题意图分流：

- **业务知识 / 产品规则 / 需求口径 / 术语解释**：只回答业务与需求结论，优先使用 `BUSINESS_CONTEXT.md`、`overview`、按问题类型命中的专项目录层、`concepts`、`entities`、`sources`。不要主动展开代码实现细节；如需说明实现相关性，只用一句话标注“本回答未核验代码实现”或“如需代码落地证据请使用 `llm-wiki query-plus`”。
- **代码实现 / 接口 / 架构 / 调用链 / 源码位置 / 前后端映射 / 实现状态**：正常进入 `wiki/code/`，按代码证据回答规则输出需求证据、代码证据、推断和缺失证据。
- **业务逻辑是否已实现 / 需求落在哪里 / 线上行为和代码是否一致**：这是业务与代码交叉问题，`query` 可以进入 `wiki/code/`，但回答应比 `query-plus` 更克制，只输出完成结论所需的关键代码证据。

判断不清时，默认按业务知识问题处理，避免过度引入代码实现噪音；可以在未决点里提示用户改用 `query-plus` 获取完整业务+代码联动答案。

### `llm-wiki query-plus`

显式要求业务和代码一起回答。无论问题表面偏业务还是偏实现，都应同时检索：

1. `BUSINESS_CONTEXT.md`
2. 业务/需求 wiki 层
3. `wiki/code/traceability`
4. `wiki/code/capabilities`
5. `wiki/code/codebases`
6. 必要时回到 `sources`、`raw/`、`raw-code/`

回答可以更详尽，必须区分：

- 业务/需求口径
- 产品或运营规则
- 代码实现现状
- 前后端/服务/任务/配置等落点
- 需求与实现的一致性、偏差或缺口
- 基于命名、图谱或矩阵的推断

## 4. 优先目录层

先用问题类型选择专项目录层，再用 `concepts / entities` 扩展和归一，最后回到 `sources` 或 `raw/` 核验证据。

### 问题 / 风险

- `conflicts`
- `evidence`
- `proposals`
- `sources`

### 方案 / 规划

- `proposals`
- `sources`

### 证据 / 结果

- `evidence`
- `sources`

### 接口 / 规则

- `reference`
- `truth`
- `sources`

### 操作 / 执行

- `operations`
- `sources`

### 代码实现 / 架构 / 调用链

- `wiki/code/traceability`
- `wiki/code/capabilities`
- `wiki/code/codebases`
- `concepts`
- `entities`
- `sources`

### 业务逻辑的实现状态

- `BUSINESS_CONTEXT.md`
- `concepts`
- `entities`
- `sources`
- `wiki/code/traceability`
- `wiki/code/capabilities`
- `wiki/code/codebases`

## 5. 实体规范

- `C1` = 卖车 C 端用户
- `C2` = 购车 C 端用户
- `车主` = `C1` 的历史别名

如果 `BUSINESS_CONTEXT.md` 有更明确的定义，以它为准。

## 6. 业务知识回答规则

当问题只是业务知识、产品规则、需求口径或术语解释时：

1. 不默认列出 `wiki/code/` 页面
2. 不展开 service / controller / endpoint / class / table / job 等实现细节
3. 不把“代码里有某接口”作为业务结论的主要证据
4. 结论优先来自业务上下文、需求文档、来源页、按意图命中的专项目录层、概念页和实体页
5. 如业务证据不足，可以说明“业务证据不足”，不要用代码实现补成业务规则
6. 如用户需要实现落地验证，建议改用 `llm-wiki query-plus`

推荐回答形状：

```text
查询类型：业务知识 / 产品规则 / 需求口径 / 术语解释
已使用 BUSINESS_CONTEXT.md：
检索路径：

结论：

业务 / 需求证据：
- ...

未决点 / 证据缺口：
- ...

实现核验：
- 本次 query 未展开代码实现；如需业务+代码联动证据，请使用 llm-wiki query-plus。
```

## 7. 代码证据回答规则

当回答涉及代码时，必须显式说明：

1. 使用了哪些 codebase
2. 使用了哪些 `wiki/code/` 页面
3. 是否回查了需求文档层
4. 哪些结论来自需求文档
5. 哪些结论来自代码实现
6. 哪些只是基于命名、调用关系或图谱的推断
7. 哪些证据仍缺失

不要把前端可见行为写成后端规则。
不要把后端接口存在写成业务一定生效。
不要把 graphify 推断边写成源码直接事实。

## 8. 跨端映射规则

前端到后端的映射优先使用稳定证据：

1. 前端 service 中的 URI 字符串
2. 后端 controller 的 `@RequestMapping` / `@GetMapping` / `@PostMapping`
3. request / response 类型名
4. controller 调用的 service
5. service 调用的 manager / dao / kafka / job

当 URI 能精确对上时，可以标记为“代码实现证明”。
当只能通过命名相似、能力页、graphify 聚类或 OpenSpec 标题关联时，只能标记为“推断”。

## 9. 追踪矩阵优先规则

当问题是实现类、测试追踪类、风险审计类或“需求落到哪里”时，优先查：

1. `wiki/code/traceability`
2. `wiki/code/capabilities`
3. `wiki/code/codebases`
4. `wiki/sources`

回答时保留矩阵中的证据强度，不要把 `partial`、`inferred`、`external`、`missing` 自动升级成确定结论。

## 10. 代码 / `query-plus` 推荐回答形状

```text
查询类型：代码实现 / 业务实现状态 / query-plus
已使用 BUSINESS_CONTEXT.md：
检索路径：

结论：

需求文档证据：
- ...

代码实现证据：
- codebase: ...
- page/service/controller/class: ...

推断：
- ...

缺失证据 / 未决点：
- ...
```

## 11. 证据链接展示规则

query 的证据链接同时服务两个目标：方便用户跳回原文阅读，以及保留本地证据快照用于复现和审计。不要把远端原文链接和本地 raw/wiki 路径混成同一种证据。

当 `raw/**/index.md` frontmatter 或 source metadata 中存在可信的 `source_url`、`page_id`、`title`、`version` 等来源元数据时：

- 普通 query 面向用户回答时，优先展示远端原文链接；链接名称可写成“原文链接”。
- 同一条证据仍应保留本地快照或本地整理页，例如 `raw/.../index.md`、`wiki/sources/...md`，用于说明本次回答依据的本地证据版本。
- 如果引用的是 `wiki/sources`、`concepts`、`entities`、`truth`、`conflicts`、`evidence`、`proposals`、`reference`、`operations` 中的二次整理内容，应标成“本地整理”或“本地证据”，不要伪装成远端原文。
- 如果 `source_url` 缺失、来源不是远端 wiki、鉴权或稳定性不确定，只展示本地证据，并明确“未找到可用原文链接”。

推荐证据形状：

```text
证据：
- 原文链接：<source_url>
- 本地快照：raw/.../index.md
- 本地整理：wiki/sources/...md
```

不同输出场景的取舍：

- 普通 query：远端原文链接优先，本地快照/整理页作为复现补充。
- doctor / update / debug：本地路径优先，必要时补充 `source_url`，因为这些命令主要检查本地 KB 状态。
- Cwiki 评论稿、IM、邮件或其他会离开本机环境的输出：只使用远端原文链接；不要暴露 `/Users/...`、`raw/...`、`wiki/...` 等本地路径。
- 代码证据：可引用 `wiki/code/...` 或 `raw-code/...` 本地证据；贴回远端评论时只描述“本地代码证据显示”，除非目标环境允许本地路径且用户明确要求。

English policy anchors for generated project rules:

- Prefer remote original wiki links when source_url/page_id metadata is available.
- Keep local raw/wiki snapshot links for reproducibility.
- Do not expose local raw/wiki paths in Cwiki comment drafts.

## Document Status Semantics

当 `staging/cjira-registry/active.json` 或 `staging/cjira-registry/archive.json` 为某个 source page 提供了记录时：

- `idea`：按 idea / proposal / exploratory evidence 描述，不要表述成已承诺范围。
- `in_progress`：按 active / in-progress requirement evidence 描述，不要直接当成稳定事实。
- `frozen`：可以作为稳定需求证据使用，但仍需遵守正常来源支持强度。
- `status_source = legacy_project_jira_reference`：表示当前 cjira 未能返回状态，但 raw 原文里明确存在旧 `project.guazi-corp.com/browse/<KEY>` 链接。旧 project Jira 已下线后，这类链接可作为迁移前历史上线/冻结证据使用；回答时说明“旧 project Jira 链接证据”，不要表述成当前 Jira API 仍可查询。
- `fetch_failed = true` 且没有 legacy project Jira reference：只能说明状态未能刷新，不能自动推断已上线、已删除或已冻结。

做 mapping 和 traceability 时：

- 优先使用 `frozen`
- 允许 `in_progress` 作为 provisional mapping
- 将 `idea` 明确标成 candidate-only，而不是 authoritative target
